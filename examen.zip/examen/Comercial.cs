class Comercial:Empleado
{private double comision {get;set;}

    public Comercial(string Nombre, int Edad, double Salario, double comision) : base(Nombre, Edad, Salario)
    {
        this.comision = comision;
    }

    

    public override void Plus()
    {
        int plus=300;
        if (Edad > 30 && comision > 200)
        {
            Salario += Salario +plus;
        }
    }
}