﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

List<Empleado> empleados = new List<Empleado>();

Comercial c1 = new Comercial("ALAN", 25, 5000, 250);
c1.Plus();
Comercial c2 = new Comercial("JERICK", 40, 6000, 350);
c2.Plus();
Repartidor r1 = new Repartidor("RONALD", 28, 3000, "Zona 3");
r1.Plus();
Repartidor r2 = new Repartidor("TUBAY", 30, 3500, "Zona 2");
r2.Plus();
Console.WriteLine(c1.ToString());
Console.WriteLine(c2.ToString());
Console.WriteLine(r1.ToString());
Console.WriteLine(r2.ToString());

empleados.Add(c1);
empleados.Add(c2);
empleados.Add(r1);
empleados.Add(r2);

foreach (Empleado e in empleados)
{
    Console.WriteLine(e.ToString());
}
