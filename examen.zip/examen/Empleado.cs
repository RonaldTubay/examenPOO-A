class Empleado
{
    public string Nombre{get; set;}
    public int Edad{get;set;}
    public double Salario {get;set;}
    public Empleado (string Nombre, int Edad, double Salario)
    {
        this.Nombre=Nombre;
        this.Edad=Edad;
        this.Salario=Salario;
    }
  

 public override string ToString()
    {
        return "Nombre: " + Nombre + ", Edad: " + Edad + ", Salario: " + Salario;
    }

    public virtual void Plus()
    {
    
    }

}