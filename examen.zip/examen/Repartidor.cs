class Repartidor:Empleado
{
    private string zona {get;set;}

    public Repartidor(string Nombre, int Edad, double Salario, string zona) : base(Nombre, Edad, Salario)
    {
        this.zona = zona;
    }


    public override void Plus()
    {
        int plus=300;
        if (Edad < 25 && zona == "Zona 3")
        {
            Salario += Salario +plus;
        }
    }

}
